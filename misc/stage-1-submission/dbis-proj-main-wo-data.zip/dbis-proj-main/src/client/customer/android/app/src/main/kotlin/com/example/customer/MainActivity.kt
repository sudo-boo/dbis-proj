package com.example.customer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
