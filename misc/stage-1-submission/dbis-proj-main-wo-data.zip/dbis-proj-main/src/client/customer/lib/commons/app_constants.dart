import 'dart:ui';

Color getPrimaryColor(){
  return Color(0xff3c006a);
}

// class _Colors {
//   final Color backgroundColor = Color(0xFFe2d7f5);
//   final Color primaryColor =
//   final Color accentColor = Color(0xff4caf50);
// }
